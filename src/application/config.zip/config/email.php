<?php if (!defined('BASEPATH')) exit('No direct script access allowed.');
           
$config['protocol']         = 'smtp';          
// $config['smtp_host']        = 'main.exsport.co.id';
// $config['smtp_user']        = 'email@exsport.co.id';
// $config['smtp_pass']        = 'empi';      
$config['smtp_host']        = 'smtp.dapenastra.com';
$config['smtp_user']        = 'NOREPLY@DAPENASTRA.COM';
$config['smtp_pass']        = 'KAJI48!';
$config['port']             =  587;
$config['mailtype']         = 'html';

/* End of email.php */
/* Location: ./application/config/email.php */
